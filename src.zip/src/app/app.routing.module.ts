import { NgModule } from "@angular/core";
import {Routes,RouterModule} from '@angular/router';
import { ChildComponent } from "./child/child.component";
import { DynamicComponent } from "./dynamic/dynamic.component";
import { FormsComponent } from "./forms/forms.component";
import { LifecycleComponent } from "./lifecycle/lifecycle.component";
import { ListenersComponent } from "./listeners/listeners.component";
import { ParentComponent } from "./parent/parent.component";
import { Child1Component } from "./routing/child1/child1.component";
import { Child2Component } from "./routing/child2/child2.component";
import { RoutingComponent } from "./routing/routing.component";


const routes: Routes = [
    {
        path:'parent',
        component:ParentComponent
    },{
        path:'child',
        component:ChildComponent
    },
    {
        path:'lifecycle',
        component:LifecycleComponent
    },
    {
        path:'forms',
        component:FormsComponent
    },
    {
        path:'dynamic-component',
        component:DynamicComponent
    },
    {
        path:'listeners',
        component:ListenersComponent
    }
    // {
    //     path: 'router',
    //     component: RoutingComponent, // this is the component with the <router-outlet> in the template
    //     children: [
    //       {
    //         path: 'child-a', // child route path
    //         component: Child1Component, // child route component that the router renders
    //       },
    //       {
    //         path: 'child-b',
    //         component: Child2Component, // another child route component that the router renders
    //       },
    //     ],
    //   },
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule],
})
export class AppRoutingModule{}