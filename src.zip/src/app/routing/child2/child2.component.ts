import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css']
})
export class Child2Component implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  submit() {
    this.router.navigateByUrl('/router/child-a')
  }
}
