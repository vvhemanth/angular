import {
  Component, AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit,
  DoCheck, OnChanges, OnDestroy, OnInit, Input, SimpleChanges
} from '@angular/core';

@Component({
  selector: 'child-component',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnChanges, OnInit, DoCheck,
AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {

@Input() message = '';

constructor() {
  console.log("ChildCompoent:Constructor");
}

ngOnChanges(chnages:SimpleChanges) {
  console.log(chnages)
  console.log("ChildComponent:OnChanges");
}


ngOnInit() {
  console.log("ChildComponent:OnInit");
}

ngDoCheck() {
  console.log("ChildComponent:DoCheck");
}

ngAfterContentInit() {
  console.log("ChildComponent:AfterContentInit");
}

ngAfterContentChecked() {
  console.log("ChildComponent:AfterContentChecked");
}

ngAfterViewInit() {
  console.log("ChildComponent:AfterViewInit");
}

ngAfterViewChecked() {
  console.log("ChildComponent:AfterViewChecked");
}

ngOnDestroy() {
  console.log("ChildComponent:OnDestroy");
}

}

