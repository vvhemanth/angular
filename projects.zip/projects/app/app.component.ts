import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // data = 'hemu';
  // data1 = false;
  data2 = 'Male';
public checkboxObject = {};
  public array = [
    {name:'gender',value:'male',heading:'male',checked:false},
    {name:'gender',value:'female',heading:'female',checked:false},
    {name:'gender',value:'other',heading:'other',checked:false}
  ]

  onChange(event) {
    this.checkboxObject = Object.assign({},event)
    console.log(event)
  }
}
